---
name: implementation-feed
description: "Deterministic ABP code generation from a locked wiki-published Feature Specification. Produces ~15–19 C# files across 6 ABP layers with 100% FS↔artifact traceability. Consumes the output of generate-feat-spec: the canonical feat-spec page plus linked DDD node pages (Entities, Commands, Queries, States, Integrations, Conflicts). Migrations remain manual."
when_to_use: "After generate-feat-spec has published a Feat Spec and its DDD node pages to the wiki, the Feat Spec has no unresolved critical/high Conflicts, and CLAUDE.md declares the required ABP conventions. Invoke per feature slug."
argument-hint: "[feature-slug]"
disable-model-invocation: true
model: "opus"
---

# Implementation Feed — ABP Feature Code Generation

**Announce at start:** "I'm using the implementation-feed skill to generate ABP code from the wiki-published Feature Specification. I'll read the Feat Spec and its DDD node pages, validate traceability, preview the artifact plan, and only write code after you approve. Migrations stay manual."

<HARD-GATE>
- Do not write any source file, modify the solution, or run any build command before the user explicitly approves the artifact preview at Phase 9.
- Do not consume a Feat Spec that still shows `[TODO]`, `[PENDING]`, `[TBD]`, `[PLACEHOLDER]`, or an **Open Blockers** section with critical/high Conflicts. Halt and escalate.
- Do not invent artifacts that have no FS source. Do not skip FS elements that have no artifact. Both conditions halt the skill.
- Do not produce repositories, controllers, domain events, or event-bus subscriptions — ABP auto-routes AppService interfaces; the domain layer publishes no events in this skill; persistence is via `IRepository<T>` directly injected.
- Do not inline user-visible strings. All messages resolve through `IStringLocalizer<TResource>` with keys declared in `Domain.Shared/Localization/Resources/<Feature>/<lang>.json`.
- Do not generate `Permissions` constants without the companion `PermissionDefinitionProvider`. The two files ship together or neither ships.
- Do not emit `{ get; set; }` on input DTOs, mutable aggregate properties outside domain methods, or aggregate constructors callable by the Application layer without going through a Builder.
- Do not run `dotnet ef migrations add` or `dotnet ef database update`. Migrations are the user's responsibility.
- Never ask questions as prose — always use the `AskUserQuestion` tool.
</HARD-GATE>

---

## Overview

This skill is the downstream counterpart to `generate-feat-spec`. Where that skill produces a wiki-published ABP-layered Feature Specification and one DDD page per Actor/Entity/Command/Query/State/Integration/Conflict/Decision, this skill *consumes* those pages and emits the C# code that implements them across six ABP project layers.

The skill reads every FS element from the wiki (Feat Spec plus linked node pages), classifies each into exactly one artifact type (Entity → Domain class, Command → Input DTO + Validator + AppService method, Query → Filter DTO + AppService method, State → enum, etc.), plans the artifact tree, validates the plan for full bidirectional traceability, previews it to the user, and only after explicit approval writes files and verifies compilation. Parallel sub-agents retrieve the wiki content, plan artifacts per ABP layer, generate code per layer, and validate the result. Migrations are always manual.

Heavy phases are delegated to purpose sub-agents at the I/O boundary. Layer generation is dispatched in parallel where layers are independent (Domain + Domain.Shared, then Application.Contracts, then Application + EntityFrameworkCore in parallel). See **Parallel Dispatch** section.

---

## Core Principle

**Every FS element becomes exactly one artifact type, and every artifact has an FS source — 100% bidirectional traceability or the skill halts.**

| FS element (wiki page or Feat Spec field) | Artifact(s) |
|---|---|
| Actor | Role constant + Permission entry |
| Command | Input DTO + Validator + AppService interface method + AppService implementation method |
| Query | Filter DTO (optionally `PagedAndSortedResultRequestDto`) + AppService interface method + AppService implementation method |
| Entity | Domain class (aggregate root or child) + EF Core configuration + Output DTO + Mapperly mapping |
| Value Object | Value object class + EF Core owned-type / value-converter config |
| State | Enum in Domain.Shared + serialization registration |
| Permission row | String constant in `<Feature>Permissions` + registration in `<Feature>PermissionDefinitionProvider` |
| Error / validation message | Key in `<Feature>Constants.ErrorMessages` + localized text in `<lang>.json` |
| Business rule | Method on aggregate OR method on `<Feature>DomainService` |
| Integration | Port interface + DI registration stub (implementation is out of scope) |
| Decision | Respected as synthesis constraint — no direct artifact |
| Conflict | Blocks the skill if severity is critical or high |

An unmapped FS element halts the skill. An orphan artifact (code with no FS source) halts the skill. No exceptions.

---

## CLAUDE.md Convention Contract

This skill reads CLAUDE.md to resolve ABP conventions. **Required** fields block Phase 0 (via `AskUserQuestion`) when missing; **recommended** fields emit a high-severity warning; **optional** fields have documented defaults.

| Field | Required | Default | Used by |
|---|---|---|---|
| `gitlab_project_id` | yes | — | Cross-reference to Feat Spec coordination issue (Phase 1 preview only) |
| `wiki_url` | yes | — | Resolve the Feat Spec canonical page |
| `wiki_local_path` | yes | `docs` | On-disk location to read the Feat Spec + DDD node pages |
| `project_root_namespace` | yes | — | All generated namespaces |
| `src_path` | yes | `src` | Solution root for 6 ABP projects |
| `module_project_layout` | no | ABP defaults (`<Ns>.Domain`, `<Ns>.Domain.Shared`, `<Ns>.Application.Contracts`, `<Ns>.Application`, `<Ns>.EntityFrameworkCore`, `<Ns>.HttpApi.Host`) | Artifact path resolution |
| `tenancy_model` | recommended | — | Aggregate interface assignment (`IMultiTenant`), AppService `TenantId` guards |
| `validation_library` | no | `FluentValidation` | Validator base class + DI registration pattern |
| `object_mapping_library` | no | `Mapperly` | Mapper interface pattern |
| `permissions_class` | no | `<Feature>Permissions` | Permissions constants class name |
| `db_table_prefix` | no | `App` | EF Core `ToTable` name |
| `sorting_strategy` | no | `explicit-switch` | Query list implementation style; `System.Linq.Dynamic.Core` requires explicit opt-in in CLAUDE.md |
| `enum_serialization` | no | `camelCase strings, global` | `JsonStringEnumConverter` registration + DTO notes |
| `api_routing_conventions` | no | ABP default `/api/app/...` | Public/Private AppService split when both prefixes declared |
| `localization_resource_name` | no | `<Feature>Resource` | `IStringLocalizer<T>` type argument |
| `notable_gotchas` | no | — | Passed verbatim to `artifact-synthesizer` as synthesis context |

**Soft warning:** If any optional field is absent, Phase 1 emits a single line listing the defaults used:

> "Using defaults for: validation_library (FluentValidation), object_mapping_library (Mapperly), sorting_strategy (explicit-switch). Declare in CLAUDE.md to override."

**Hard fail:** Generating code that contradicts CLAUDE.md (e.g., AutoMapper when CLAUDE.md says Mapperly, `System.Linq.Dynamic.Core` when CLAUDE.md says `explicit-switch`) is a traceability defect caught by the validator. Conventions are non-negotiable.

---

## FS Retrieval Model

The Feat Spec lives at `<wiki_local_path>/feat-specs/<feature-slug>/feat-spec.md`. Every DDD node page lives at `<wiki_local_path>/<node-type>/<NodeName>.md` and is referenced from the Feat Spec via `wiki_url`-prefixed links.

**Retrieval rules:**

- The Feat Spec is the entry point. `fs-loader` follows every wiki link from the Feat Spec to its source pages and extracts the node-type + name from the URL.
- The skill reads **only on-disk** wiki files (no HTTP fetch) at `<wiki_local_path>/<node-type>/<file>.md`. The `wiki_url` in rendered links is ignored for resolution — it exists to render in the browser, not to drive retrieval.
- Pages not referenced from the Feat Spec are not read, even if they exist in the folder.
- `Conflict` pages referenced by the Feat Spec are read and evaluated for blocking severity.
- `Decision` pages are read and stored as synthesis constraints for `artifact-synthesizer`.

**Halt conditions during retrieval:**

- Feat Spec missing on disk → halt, ask user to verify `generate-feat-spec` ran.
- A node link resolves to a missing file → halt, report broken links.
- Feat Spec contains any of `[TODO]`, `[PENDING]`, `[TBD]`, `[PLACEHOLDER]` → halt, ask user to re-run `generate-feat-spec`.
- Feat Spec **Open Blockers** section lists a Conflict with severity `critical` or `high` → halt.

---

## When NOT to Use

- No Feat Spec on disk for the given `<feature-slug>`.
- Feat Spec has unresolved critical/high Conflicts.
- Feat Spec contains placeholder tokens.
- CLAUDE.md is absent or missing any required field.
- ABP solution scaffolding absent (six projects not found under `<src_path>`).
- User wants code for requirements not yet captured in a Feat Spec — invoke `generate-feat-spec` first.

---

## Quick Reference

| Phase | Action | Delegated to | Parallel? | Gate |
|---|---|---|---|---|
| 0 | Scope preview | main | — | User confirms feature slug + CLAUDE.md |
| 1 | Read CLAUDE.md convention contract | main | — | Halt if required fields missing |
| 2 | Load Feat Spec + linked DDD pages | `fs-loader` | Yes — parallel page reads | Halt on placeholders, broken links, blocking Conflicts |
| 3 | Solution structure validation | `solution-inspector` | No | Halt if any of 6 projects / DbContext / module files missing |
| 4 | Inventory extraction, FS element catalog | main | — | All FS elements enumerated |
| 5 | Aggregate boundary analysis | main | — | One aggregate root per module; children identified |
| 6 | Artifact planning per layer | `artifact-planner` | Yes — per layer | Bidirectional mapping complete |
| 7 | Traceability validation (plan) | `traceability-validator` | No | Unmapped FS = 0 AND orphan artifacts = 0 |
| 8 | Assemble artifact preview | main | — | Full path list + per-file summary |
| 9 | **Preview + approval gate** | main (`AskUserQuestion`) | — | **No writes without `approve`** |
| 10 | Code synthesis per layer | `artifact-synthesizer` | Yes — per layer cohort | Compiles in isolation |
| 11 | Compile + post-write validation | `build-validator` | No | `dotnet build` passes; repair loop on failure |
| 12 | Final traceability report | main | — | Report written, next steps enumerated |

Migrations are never a phase — they are a post-skill manual step documented in the report.

---

## Parallel Dispatch

### Phase 2 — `fs-loader` parallel page reads

- **Dispatch rule:** after parsing Feat Spec wiki links, if ≥3 DDD node pages are referenced, read them in parallel batches.
- **Scope per worker:** list of `{node-type, file-path}` tuples. Each worker returns structured extraction of entries.
- **Rejoin:** main `fs-loader` consolidates into the FS element catalog.
- **Why parallel-safe:** file reads are independent, no shared state.

### Phase 6 — `artifact-planner` per-layer planning

- **Dispatch rule:** one planner per ABP layer (Domain, Domain.Shared, Application.Contracts, Application, EntityFrameworkCore) — always 5 workers. Domain Services layer is planned inside the Domain planner since it depends on aggregate boundaries.
- **Scope per worker:** the FS element catalog + CLAUDE.md convention contract + the layer-specific reference file.
- **Rejoin:** main merges per-layer plans into a single artifact manifest.
- **Why parallel-safe:** planning does not write files; each planner emits descriptors, not code.

### Phase 10 — `artifact-synthesizer` layered cohorts

Code generation must respect inter-layer compilation order, so parallelism is bounded by dependency cohorts:

- **Cohort A (parallel):** Domain.Shared — enums, constants, roles, localization. No dependencies.
- **Cohort B (parallel):** Domain — aggregates, domain services. Depends on A.
- **Cohort C (parallel):** Application.Contracts — permissions, DTOs, validators, AppService interfaces. Depends on A.
- **Cohort D (parallel):** Application + EntityFrameworkCore — AppService implementations, mappers, EF configurations, DI. Depends on B and C.

Within each cohort, files are written in parallel. Between cohorts, the skill waits.

- **Why cohort-gated:** C# compilation graph forbids cross-cohort parallelism, but every file in a cohort is independent of every other file in the same cohort.

### What is NOT parallelized

- `solution-inspector` — one pass over the solution root.
- `traceability-validator` — requires whole-plan view to detect orphans and gaps.
- `build-validator` — one `dotnet build` invocation.
- Repair loops — surgical, serial.

### Parallelization guidance

Each parallel worker receives only its slice of the FS element catalog plus the references it needs. Do not forward the full Feat Spec to every worker. Per-sub-agent input schemas live in `agents/<sub-agent>.md`.

---

## Hard Rules / Constraints

<HARD-GATE>
- **Approval gate is absolute.** No file write before Phase 9 approval. Preview is read-only.
- **FS lock check.** Feat Spec must contain no `[TODO]`, `[PENDING]`, `[TBD]`, `[PLACEHOLDER]` and no critical/high blocking Conflicts.
- **Bidirectional traceability.** Every FS element → artifact(s). Every artifact ← FS element. Gap on either side halts the skill.
- **Tenancy.** Aggregates inherit `FullAuditedAggregateRoot<Guid>`; `IMultiTenant` is added only when CLAUDE.md `tenancy_model` plus the Entity page declare it. TenantId guards on every AppService method when `IMultiTenant` is present.
- **Domain layer purity.** No HTTP calls, no direct persistence, no `ILocalEventBus`, no event publishing. Invariants only.
- **Domain Services.** Mandatory for multi-aggregate orchestration, cross-aggregate calculations, external-system validation, or reorder/state-transition logic referenced by ≥2 Commands. Otherwise omitted.
- **AppServices are HTTP endpoints.** ABP auto-routes interface methods; no manual controllers.
- **IRepository<T> direct injection.** No repository layer, no generic repository abstractions on top of ABP's.
- **Builder pattern on aggregate creation.** Nested `Builder` with `Build()` validation; static `Create(...)` factory delegates to the builder.
- **Input DTO immutability.** Every input DTO property is `{ get; init; }`. Output DTOs use `{ get; set; }` so ABP serialization and Mapperly cooperate.
- **Validation via CLAUDE.md `validation_library`.** Default FluentValidation. Validators inject `IStringLocalizer<TResource>` and reference keys from `<Feature>Constants.ErrorMessages`.
- **Object mapping via CLAUDE.md `object_mapping_library`.** Default Mapperly. Interface with `[Mapper]` attribute, no manual property assignment in AppServices.
- **Permissions shipped as a pair.** `<Feature>Permissions` constants + `<Feature>PermissionDefinitionProvider` that inherits `PermissionDefinitionProvider`, overrides `Define(IPermissionDefinitionContext)`, and registers Group → per-entity parent → CRUD + custom children. Localization keys follow `<Feature>:Permission:<Name>`.
- **Authorization everywhere.** `[Authorize(<permission>)]` on every AppService method — reads and writes.
- **Sorting per `sorting_strategy`.** Default `explicit-switch`. `System.Linq.Dynamic.Core` forbidden unless CLAUDE.md opts in.
- **Enum serialization.** Global `JsonStringEnumConverter(JsonNamingPolicy.CamelCase)` registration verified in `HttpApi.Host`; if missing, the skill adds it as part of the plan.
- **No `IHasExtraProperties`.** All fields declared explicitly on every entity and DTO.
- **Optimistic locking.** Update DTOs carry `ConcurrencyStamp`; ABP's base classes handle validation.
- **Audit fields.** Provided by `FullAuditedAggregateRoot` — never redeclared.
- **Optional filters via `WhereIf`.** No `if`/`else` filter chains in query methods.
- **Manual migrations.** The skill generates EF configurations and halts. The user runs `dotnet ef migrations add` and `dotnet ef database update`.
- **Atomicity per cohort.** Cohort completion means every file in the cohort written and compiled. Partial cohort = rollback that cohort and halt.
- **Namespaces from CLAUDE.md.** `project_root_namespace` drives every generated namespace. Zero hardcoded strings.
- **Localization files only under `Domain.Shared`.** `Application` layer never declares resource files.
- **Public/Private split honored.** When CLAUDE.md declares both `api_routing_conventions.public_prefix` and `.private_prefix`, each Command/Query is routed per its `**Audience:**` field on the FS page. If the Feat Spec omits Audience when a split is declared → Conflict → halt.
</HARD-GATE>

---

## Anti-Patterns

### ❌ Reading a Feat Spec that still contains `[TODO]`

**Why wrong:** Placeholders conceal undecided requirements. Generating against them produces code that must be thrown away as soon as the decision is made.

✅ **Correct:** `fs-loader` scans for placeholder tokens before extraction. Any hit halts the skill with "Re-run generate-feat-spec; Feat Spec contains unresolved placeholders at <line numbers>."

### ❌ Proceeding past Phase 9 without explicit `approve`

**Why wrong:** The preview is non-destructive. Writing code before the user sees the plan eliminates the whole point of having a planning skill.

✅ **Correct:** Phase 9 uses `AskUserQuestion` with three options: `approve`, `revise`, `cancel`. Only `approve` transitions to Phase 10.

### ❌ Treating Domain Services as optional for multi-aggregate orchestration

**Why wrong:** Putting cross-aggregate coordination in AppServices bloats them, hides business rules in plumbing, and blocks reuse across Commands that touch the same flow.

✅ **Correct:** `artifact-planner` flags a Domain Service as mandatory when the Feat Spec describes any of: multi-aggregate state change, reorder/ranking across a sibling set, cross-aggregate calculation, external-system validation, or a business rule referenced by ≥2 Commands. AppServices in that module call the Domain Service.

### ❌ Merging Public and Private AppServices into one class

**Why wrong:** Customer-facing and backoffice operations have different permission sets, different audiences, and different validation envelopes. Mixing them couples concerns and invites authorization mistakes.

✅ **Correct:** When CLAUDE.md declares a Public/Private split, emit `<Feature>PublicAppService` and `<Feature>PrivateAppService` with their corresponding interfaces. The FS Command/Query `**Audience:**` field routes each method to the right class.

### ❌ Hardcoded strings in validators or aggregates

**Why wrong:** Breaks i18n. Duplicates messages across validators. Makes message changes a code change.

✅ **Correct:** All user-visible messages are keys in `<Feature>Constants.ErrorMessages`; validators inject `IStringLocalizer<<Feature>Resource>["<Key>"]`. Aggregates throw `BusinessException` with a code resolved by ABP's exception localization.

### ❌ Generating `<Feature>Permissions` without `<Feature>PermissionDefinitionProvider`

**Why wrong:** The constants exist in code but ABP never registers them with the authorization system. `[Authorize(...)]` attributes silently fail or bypass.

✅ **Correct:** The two files ship as a pair in Cohort C. `traceability-validator` fails the plan if one exists without the other.

### ❌ Mutable input DTOs

**Why wrong:** Validators pass, then a later layer mutates the DTO before the domain sees it. The validation contract is worthless.

✅ **Correct:** `{ get; init; }` on every input DTO property. Synthesizer rejects any input DTO with `set;`.

### ❌ Aggregate creation without the Builder

**Why wrong:** Invariants are enforced post-construction, which means an invalid aggregate exists in memory between `new` and the validation call.

✅ **Correct:** Private constructor. Static `Create(...)` → nested `Builder` → `Build()` validates and returns the aggregate. AppServices only ever call `Create(...)`.

### ❌ Domain events in the Domain layer

**Why wrong:** Events are an integration concern, not an invariant concern. Coupling the domain to an event bus drags infrastructure into the center of the model.

✅ **Correct:** No `ILocalEventBus`, no `AddLocalEvent`, no `AddDistributedEvent` in the Domain layer. If the FS says an event is required, it lives in the Application layer or an outbox adapter — both out of scope for this skill.

### ❌ Skipping TenantId guards on reads

**Why wrong:** Tenant A reads Tenant B's data. Multi-tenancy violated.

✅ **Correct:** Every AppService method — `GetAsync`, `GetListAsync`, `UpdateAsync`, `DeleteAsync`, plus any custom op — enforces `if (aggregate.TenantId != CurrentTenant.Id) throw new AbpAuthorizationException(...);` after load, and filters queries by `TenantId` before executing.

### ❌ AutoMapper when CLAUDE.md says Mapperly

**Why wrong:** Runtime reflection, untyped property strings, missing compile-time errors. Also contradicts the convention contract.

✅ **Correct:** `[Mapper]`-annotated interface; Mapperly generates the implementation. AppService injects the interface.

### ❌ `System.Linq.Dynamic.Core` when `sorting_strategy` is `explicit-switch`

**Why wrong:** Open sorting surface = injection vector on column names. Explicit-switch is auditable and safe.

✅ **Correct:** Query `GetListAsync` uses `switch (input.Sorting?.Trim())` over a whitelisted set of column keys, defaulting to the default sort declared on the Query's wiki page.

### ❌ Unmapped FS element

**Why wrong:** A requirement was documented but nothing implements it. The feature is incomplete.

✅ **Correct:** `traceability-validator` emits a defect for every FS element that has no artifact. Halt until the plan is extended.

### ❌ Orphan artifact

**Why wrong:** Code exists with no requirement. Scope creep, dead code, or speculative abstraction.

✅ **Correct:** `traceability-validator` emits a defect for every artifact that has no `**Source:**` back to an FS page. Halt until the artifact is removed or a source is identified.

### ❌ Running migrations inside the skill

**Why wrong:** Schema changes carry deployment impact. Automating them inside a code-gen skill strips the human decision.

✅ **Correct:** Phase 7 generates EF configurations. The final report documents the exact `dotnet ef migrations add` and `dotnet ef database update` commands. The user runs them.

### ❌ Asking questions as prose

✅ **Correct:** Always use the `AskUserQuestion` tool.

---

## Checklist

You MUST complete these in order:

1. Phase 0 — Scope preview via `AskUserQuestion` confirming the feature slug and CLAUDE.md location.
2. Phase 1 — Read CLAUDE.md convention contract. Halt on missing required fields; warn on missing recommended; emit soft warning for optional defaults used.
3. Phase 2 — Dispatch `fs-loader` (parallel page reads if ≥3 pages). Receive FS element catalog, placeholder scan result, blocking-Conflict scan result.
4. Phase 3 — Dispatch `solution-inspector`. Halt if any of 6 projects / DbContext / module files / folder scaffolding missing.
5. Phase 4 — Build FS element catalog: enumerate Actors, Entities, Commands, Queries, States, Permissions, Error Messages, Business Rules, Integrations, Decisions.
6. Phase 5 — Aggregate boundary analysis: one root per module, children identified, load strategy declared, tenancy resolved from the Entity page + CLAUDE.md.
7. Phase 6 — Dispatch `artifact-planner` per layer (5 parallel workers). Merge into a single artifact manifest.
8. Phase 7 — Dispatch `traceability-validator`. Unmapped FS count = 0 AND orphan-artifact count = 0.
9. Phase 8 — Assemble preview: full file path list, per-file one-line summary, traceability matrix excerpt, CLAUDE.md defaults used, migration command preview.
10. Phase 9 — `AskUserQuestion` approval gate. Only `approve` proceeds.
11. Phase 10 — Dispatch `artifact-synthesizer` per cohort (A → B → C → D). Each cohort's files written in parallel; cohorts serial.
12. Phase 11 — Dispatch `build-validator`. On failure: surgical repair via `artifact-synthesizer` in repair mode; re-validate; loop until green.
13. Phase 12 — Write `IMPLEMENTATION_REPORT_<Feature>.md`. Enumerate next steps (migration command, review checklist, test targets). Never run `dotnet ef` commands.

---

## Process Flow

```dot
digraph implementation_feed {
    node [fontname="monospace"];

    P0  [shape=box,     label="Phase 0: Scope preview"];
    P1  [shape=box,     label="Phase 1: CLAUDE.md contract"];
    P2  [shape=box,     label="Phase 2: fs-loader\n(parallel page reads)"];
    P2C [shape=diamond, label="FS locked + no\nblocking Conflicts?"];
    P2H [shape=box,     label="Halt: re-run generate-feat-spec"];
    P3  [shape=box,     label="Phase 3: solution-inspector"];
    P3C [shape=diamond, label="6 projects + modules\n+ DbContext present?"];
    P3H [shape=box,     label="Halt: fix solution scaffolding"];
    P4  [shape=box,     label="Phase 4: FS element catalog"];
    P5  [shape=box,     label="Phase 5: Aggregate analysis"];
    P5C [shape=diamond, label="Boundaries clear?"];
    P5Q [shape=box,     label="AskUserQuestion"];
    P6  [shape=box,     label="Phase 6: artifact-planner\n(5 parallel workers)"];
    P7  [shape=box,     label="Phase 7: traceability-validator"];
    P7C [shape=diamond, label="Unmapped=0 AND\norphans=0?"];
    P7H [shape=box,     label="Halt: gap report"];
    P8  [shape=box,     label="Phase 8: Assemble preview"];
    P9  [shape=box,     label="Phase 9: Approval gate"];
    P9C [shape=diamond, label="User decision?"];
    P9R [shape=box,     label="Revision loop\nto Phase 6"];
    P9X [shape=box,     label="Cancel\nno side effects"];
    P10 [shape=box,     label="Phase 10: artifact-synthesizer\nCohorts A→B→C→D"];
    P11 [shape=box,     label="Phase 11: build-validator"];
    P11C[shape=diamond, label="Build green?"];
    P11R[shape=box,     label="Repair loop"];
    P12 [shape=box,     label="Phase 12: Final report\nManual migration next"];

    P0  -> P1 -> P2 -> P2C;
    P2C -> P3  [label="yes"];
    P2C -> P2H [label="no"];
    P3  -> P3C;
    P3C -> P4  [label="yes"];
    P3C -> P3H [label="no"];
    P4  -> P5 -> P5C;
    P5C -> P6  [label="yes"];
    P5C -> P5Q [label="no"];
    P5Q -> P6;
    P6  -> P7 -> P7C;
    P7C -> P8  [label="yes"];
    P7C -> P7H [label="no"];
    P8  -> P9 -> P9C;
    P9C -> P10 [label="approve"];
    P9C -> P9R [label="revise"];
    P9C -> P9X [label="cancel"];
    P9R -> P6;
    P10 -> P11 -> P11C;
    P11C-> P12 [label="yes"];
    P11C-> P11R[label="no"];
    P11R-> P11;
}
```

---

## The Process

### Phase 0: Scope Preview

1. Read `<feature-slug>` from invocation arguments. If absent → `AskUserQuestion` listing slugs found under `<wiki_local_path>/feat-specs/`.
2. Verify CLAUDE.md is readable. If absent → `AskUserQuestion` asking for its path.
3. `AskUserQuestion`:
   > I'm about to generate ABP code for feature **<slug>**. This reads the wiki Feat Spec + its linked DDD node pages, inspects your ABP solution at `<src_path>`, plans ~15–19 C# files across 6 layers, and previews the plan before writing anything. Migrations remain manual. Proceed?
   Options: `proceed` / `change slug` / `cancel`.
4. Do not continue without `proceed`.

### Phase 1: CLAUDE.md Convention Contract

1. Extract fields per the convention contract table.
2. Missing required field → `AskUserQuestion` surfacing which field and why it blocks.
3. Missing `tenancy_model` → emit warning: "tenancy_model not declared; aggregates will NOT inherit IMultiTenant unless a specific Entity page declares it explicitly."
4. Emit soft warning line listing optional defaults used.
5. Store the resolved contract for downstream sub-agents.

### Phase 2: FS Load (Sub-agent: `fs-loader`)

See `agents/fs-loader.md`.

- **Input:** `wiki_local_path`, `feature-slug`, `gitlab_base_url` (for source-field parsing).
- **Tools:** filesystem read only.
- **Parallel:** ≥3 linked node pages → parallel reads.
- **Returns:** FS element catalog (Entities with attribute tables, Commands with validation refs + audience, Queries with filter/sort contracts, States with transitions, Permissions map, Integrations with failure boundaries, Decisions as constraints, Conflicts with severity), placeholder-scan result, blocking-Conflict scan result.

Halt conditions enforced by the sub-agent:

- Feat Spec missing.
- Any placeholder token.
- Any Conflict referenced from Open Blockers with severity `critical` or `high`.
- Any referenced DDD page missing on disk.

### Phase 3: Solution Inspection (Sub-agent: `solution-inspector`)

See `agents/solution-inspector.md`.

- **Input:** `src_path`, `project_root_namespace`, `module_project_layout`.
- **Tools:** filesystem read only, `dotnet sln list` allowed.
- **Returns:** presence matrix for the 6 projects, their module classes, the DbContext class + `OnModelCreating` inspection result, the presence of `Localization/Resources/<Feature>`, `Constants/`, `Enums/`, `Roles/`, `Permissions/` folders under each project.

Halt conditions:

- Any of 6 projects absent.
- Any module class absent.
- DbContext absent or `OnModelCreating` does not call `ApplyConfigurationsFromAssembly`.
- `HttpApi.Host` not registering a global `JsonStringEnumConverter(CamelCase)` when `enum_serialization` = default — planner will plan to add it, not halt.

### Phase 4: FS Element Catalog

Main agent.

1. From `fs-loader` output, produce a single table per element type with stable ordering.
2. Attach source anchors (wiki URLs with heading anchors) to each row for downstream Source field emission.
3. Cross-check every Command/Query against the Entities it operates on — an orphan Command (no Entity) raises a Conflict.

### Phase 5: Aggregate Boundary Analysis

Main agent.

1. For each module, identify exactly one aggregate root. If ambiguous → `AskUserQuestion`.
2. Identify child entities and the load strategy declared on the root's wiki page.
3. Resolve tenancy: `IMultiTenant` only when `tenancy_model` is declared AND the Entity page confirms it.
4. Declare ConcurrencyStamp presence from the Entity page or CLAUDE.md convention.

### Phase 6: Artifact Planning (Sub-agent: `artifact-planner`)

See `agents/artifact-planner.md`.

Dispatch 5 workers in parallel, one per layer:

| Worker | Plans |
|---|---|
| Domain | Aggregate roots, child entities, Value Objects, Domain Service (if mandatory), static factory + Builder, domain methods |
| Domain.Shared | Enums, `<Feature>Constants` with nested `ErrorMessages`, `<Feature>Roles`, `<Feature>Resource` marker class, `<lang>.json` |
| Application.Contracts | `<Feature>Permissions`, `<Feature>PermissionDefinitionProvider`, Input/Update/Output DTOs, Validators, AppService interfaces |
| Application | AppService implementations (Public/Private per audience), Mapperly interface, DI registration additions to `<Feature>ApplicationModule` |
| EntityFrameworkCore | `IEntityTypeConfiguration<T>` per entity, `OnModelCreating` verification, `JsonStringEnumConverter` registration (if missing) |

Each worker returns an artifact manifest: `{ layer, files: [{ path, kind, source_fs_element, summary }] }`.

### Phase 7: Traceability Validation (Sub-agent: `traceability-validator`)

See `agents/traceability-validator.md`.

- **Input:** merged artifact manifest + FS element catalog.
- **Returns:** `{ passed, forward_gaps: [...], backward_orphans: [...], convention_violations: [...] }`.

Failure modes:

- Forward gap — FS element with no artifact.
- Backward orphan — artifact with no FS source.
- Convention violation — artifact contradicts CLAUDE.md (e.g., planned AutoMapper mapper when `object_mapping_library` = Mapperly).

Any failure → halt with a structured gap report.

### Phase 8: Preview Assembly

Main agent.

Assemble a preview document:

1. Feature metadata (slug, module count, aggregate count).
2. File path tree grouped by layer.
3. Per-file one-line summary + FS source link.
4. Traceability matrix excerpt (every FS element → artifact paths).
5. CLAUDE.md defaults used.
6. Migration preview: exact `dotnet ef migrations add` and `dotnet ef database update` commands the user will run after approval.
7. Any warnings (e.g., "JsonStringEnumConverter missing from HttpApi.Host; will be added").

### Phase 9: Approval Gate

Main agent.

Present the preview, then `AskUserQuestion`:

```
Approve this plan for code generation?

  approve  — write files in cohorts A→B→C→D, verify build
  revise   — adjust plan; provide feedback
  cancel   — no side effects
```

`approve` → Phase 10. Anything else → loop or exit. No file writes before `approve`.

### Phase 10: Code Synthesis (Sub-agent: `artifact-synthesizer`)

See `agents/artifact-synthesizer.md`.

Dispatch cohorts serially; within each cohort, dispatch per-file workers in parallel.

- **Cohort A — Domain.Shared:** enums, constants, roles, resource marker, `<lang>.json`.
- **Cohort B — Domain:** aggregates with Builder, child entities, Value Objects, Domain Service.
- **Cohort C — Application.Contracts:** Permissions + Provider, DTOs, Validators, AppService interfaces.
- **Cohort D — Application + EntityFrameworkCore:** AppService implementations, Mapperly interface, DI registration, EF configurations.

Each synthesizer worker returns `{ path, written, bytes, compile_hint }`. A worker never writes outside its cohort.

Between cohorts, the skill may optionally run `dotnet build` on the written projects to fail fast on a broken cohort; default is to defer to Phase 11.

### Phase 11: Build Validation (Sub-agent: `build-validator`)

See `agents/build-validator.md`.

- **Input:** `src_path`.
- **Tool:** `dotnet build` against the solution.
- **Returns:** `{ passed, errors: [{file, line, message}], warnings }`.

On failure: dispatch `artifact-synthesizer` in repair mode with only the affected files + the error payload. Re-validate. Loop with a hard cap of 3 repair iterations; after that → halt with the build output and a defect summary.

### Phase 12: Final Report

Main agent.

Write `<docs>/feat-specs/<feature-slug>/IMPLEMENTATION_REPORT_<Feature>.md` containing:

1. Feature metadata + timestamp.
2. File count per layer.
3. Artifact inventory (path, kind, FS source link).
4. Full traceability matrix.
5. CLAUDE.md contract resolved (required + used defaults).
6. Build status (`dotnet build` summary).
7. **Manual next steps:**
   - `dotnet ef migrations add Add<Feature>Tables --context <Ns>DbContext --output-dir Migrations`
   - `dotnet ef database update --context <Ns>DbContext`
   - Review checklist pointing at wiki Feat Spec.
   - Suggested integration + unit test targets per AppService.

---

## Handling Outcomes

**PREVIEWABLE** — All validations green; proceed to Phase 9.
**NEEDS_REPAIR_PLAN** — Traceability validator failed; targeted re-plan on affected layer(s); re-validate.
**NEEDS_REPAIR_BUILD** — Build failed post-write; surgical synthesis on affected files; re-build; cap 3 iterations.
**FS_NOT_LOCKED** — Halt. Ask user to re-run `generate-feat-spec`.
**FS_HAS_BLOCKING_CONFLICT** — Halt. List Conflicts with severity and wiki links.
**FS_NOT_FOUND** — Halt. Suggest invocation of `generate-feat-spec`.
**CLAUDE_MD_INCOMPLETE** — Halt. List missing required fields.
**SOLUTION_SCAFFOLDING_MISSING** — Halt. List missing projects/modules/DbContext elements.
**AGGREGATE_AMBIGUOUS** — `AskUserQuestion` to resolve root per module.
**PUBLIC_PRIVATE_SPLIT_MISSING_AUDIENCE** — Halt. FS has Audience-less Command/Query with split declared in CLAUDE.md.
**USER_REVISION_REQUESTED** — Collect feedback; return to Phase 6 with changes.
**USER_CANCELLED** — No side effects. Exit cleanly.
**BUILD_UNRECOVERABLE** — Halt after 3 repair iterations. Output build log + defect summary; do not delete written files (leave them for human inspection).

---

## Constraints

**Never:**

- Write any file before Phase 9 approval.
- Run any `dotnet` command other than `dotnet build` (inspection) and `dotnet sln list` (inspection).
- Run `dotnet ef migrations add` or `dotnet ef database update`.
- Consume a Feat Spec that has placeholders or blocking Conflicts.
- Hardcode namespaces, table names, permission strings, or messages.
- Synthesize a `Permissions` constants class without its `PermissionDefinitionProvider` companion.
- Emit `{ get; set; }` on input DTOs.
- Emit aggregate public constructors callable by the Application layer.
- Add `ILocalEventBus`, `IDistributedEventBus`, or event publishing to the Domain layer.
- Merge Public and Private AppServices when CLAUDE.md declares a split.
- Use AutoMapper when `object_mapping_library` = Mapperly.
- Use `System.Linq.Dynamic.Core` when `sorting_strategy` = explicit-switch.
- Put localization resource files in the Application layer.
- Silently skip an FS element without emitting a traceability defect.
- Write code that has no `**Source:**` back to an FS page.
- Ask questions as prose.

---

## Tool Permissions

| Tool | Purpose | Phase | Type | Called by |
|---|---|---|---|---|
| Filesystem read | Wiki pages, CLAUDE.md, solution inspection | 1, 2, 3 | read | main + `fs-loader` + `solution-inspector` |
| Filesystem write | Artifact generation | 10, 12 | write | `artifact-synthesizer` (only after approval) |
| `dotnet build` | Compile verification | 11 | read-ish | `build-validator` |
| `dotnet sln list` | Project enumeration | 3 | read | `solution-inspector` |
| `AskUserQuestion` | Phase 0, 1 (missing config), 5 (aggregate ambiguity), 9 (approval) | various | interactive | main |

**Not permitted:** `dotnet ef migrations *`, `dotnet ef database *`, `dotnet run`, `dotnet test`, network calls, wiki writes, GitLab writes.

---

## Sub-agent Contracts Summary

| Sub-agent | Phase | Model | Parallel? | Contract |
|---|---|---|---|---|
| `fs-loader` | 2 | Haiku | Yes — per page | `agents/fs-loader.md` |
| `solution-inspector` | 3 | Haiku | No | `agents/solution-inspector.md` |
| `artifact-planner` | 6 | Sonnet | Yes — 5 per layer | `agents/artifact-planner.md` |
| `traceability-validator` | 7 | Haiku | No | `agents/traceability-validator.md` |
| `artifact-synthesizer` | 10 + repair | Opus | Yes — per-file in cohort | `agents/artifact-synthesizer.md` |
| `build-validator` | 11 | Haiku | No | `agents/build-validator.md` |

---

## Artifact Path Layout

Relative to `<src_path>`, with `<Ns>` = `project_root_namespace`, `<F>` = PascalCase feature name:

```
<Ns>.Domain/
  <F>/
    <AggregateRoot>.cs
    <ChildEntity>.cs                          (if any)
    <ValueObject>.cs                          (if any)
    DomainServices/
      <F>Service.cs                           (if mandatory)

<Ns>.Domain.Shared/
  <F>/
    Enums/
      <State>Enum.cs
    Constants/
      <F>Constants.cs
    Roles/
      <F>Roles.cs                             (if actors)
    Localization/
      <F>Resource.cs
  Localization/Resources/<F>/
    en.json

<Ns>.Application.Contracts/
  <F>/
    Permissions/
      <F>Permissions.cs
      <F>PermissionDefinitionProvider.cs
    Dtos/
      Create<Entity>Dto.cs
      Update<Entity>Dto.cs
      <Entity>Dto.cs
      Get<Entity>ListDto.cs
    Validators/
      Create<Entity>Validator.cs
      Update<Entity>Validator.cs
    I<F>PublicAppService.cs                   (per audience split)
    I<F>PrivateAppService.cs                  (per audience split)

<Ns>.Application/
  <F>/
    <F>PublicAppService.cs
    <F>PrivateAppService.cs
    <F>Mapper.cs                              (Mapperly interface)

<Ns>.EntityFrameworkCore/
  <F>/
    <Entity>Configuration.cs
```

---

## Wiki Source Field on Every Artifact

Every generated file carries a file-header XML doc comment:

```
/// <summary>
/// <see href="<wiki_url>/<node-type>/<NodeName>"/>
/// </summary>
```

This is the runtime counterpart to the `**Source:**` field the FS uses. The final traceability report uses these comments to prove coverage.

---

## Integration

**Required before:**

- `generate-feat-spec` has been run and the Feat Spec + DDD node pages are published to the wiki.
- CLAUDE.md has the required fields.
- ABP solution scaffolding is present.

**Delegates to:** `fs-loader`, `solution-inspector`, `artifact-planner`, `traceability-validator`, `artifact-synthesizer`, `build-validator`.

**Required after:**

- User runs migration commands from the final report.
- Human code review against the wiki Feat Spec.
- Test authoring (out of scope for this skill).

**Alternative:** If the feature has no Feat Spec, invoke `generate-feat-spec` first. Do not hand-author an FS to feed this skill.

---

## Reference Files

| Category | File |
|---|---|
| ABP base classes | `references/abp-base-classes.md` |
| ABP built-in entities | `references/abp-built-in-entities.md` |
| Domain aggregates + Builder pattern | `references/domain-layer.md` |
| Domain Services | `references/domain-services.md` |
| Domain.Shared layout | `references/domain-shared-layer.md` |
| Permissions + Provider pattern | `references/permissions.md` |
| DTOs + Validators (FluentValidation) | `references/dtos-validators.md` |
| Mapperly patterns | `references/mapperly.md` |
| AppService implementation patterns | `references/appservices.md` |
| EF Core configuration | `references/ef-core.md` |
| Localization | `references/localization.md` |
| Implementation report template | `templates/implementation-report-template.md` |

## Sub-agent Files

| Sub-agent | File |
|---|---|
| FS loader | `agents/fs-loader.md` |
| Solution inspector | `agents/solution-inspector.md` |
| Artifact planner | `agents/artifact-planner.md` |
| Traceability validator | `agents/traceability-validator.md` |
| Artifact synthesizer | `agents/artifact-synthesizer.md` |
| Build validator | `agents/build-validator.md` |

---

## Expected Output

- ~15–19 C# files across 6 ABP layers, all compiling.
- One `IMPLEMENTATION_REPORT_<Feature>.md` under `<wiki_local_path>/feat-specs/<feature-slug>/`.
- 100% bidirectional FS↔artifact traceability.
- No migrations run. Exact commands documented for the user.
- Every file carries an XML doc link back to its wiki source.

---

## Verification

1. ✓ Feat Spec consumed from wiki with no placeholders and no blocking Conflicts.
2. ✓ CLAUDE.md convention contract honored — zero silent deviations.
3. ✓ Every FS element mapped; every artifact traced.
4. ✓ `dotnet build` green.
5. ✓ All hard rules enforced (Builder, init-only DTOs, Permissions pair, Authorize everywhere, TenantId guards, no domain events).
6. ✓ Implementation report written with manual next steps.

---

## Next Step

After completing:

1. Run the migration commands from the report.
2. Apply the migration to the database.
3. Review the generated code against the wiki Feat Spec.
4. Author unit + integration tests per AppService.
5. Commit and deploy.

→ **Return to `generate-feat-spec` for the next milestone.**
