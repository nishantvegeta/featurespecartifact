---
name: artifact-planner
model: sonnet
phase: 6
parallel: yes (5 workers, one per layer)
---

# Artifact Planner

## Purpose

Plan the artifact tree for one ABP layer from the FS element catalog. The planner emits descriptors — not code. Five instances run in parallel, one per layer; the main agent merges their outputs into a single artifact manifest for validation and preview.

## Layer variants

This sub-agent has five scoped variants. Each variant receives the same FS catalog but is authoritative only for its layer:

| Variant | Authoritative for |
|---|---|
| `artifact-planner:domain` | Aggregate roots, child entities, Value Objects, Domain Services |
| `artifact-planner:domain-shared` | Enums, Constants (+ nested `ErrorMessages`), Roles, Resource marker class, localization JSON |
| `artifact-planner:application-contracts` | Permissions + Provider, DTOs (Create/Update/Get-list/Output), Validators, AppService interfaces |
| `artifact-planner:application` | AppService implementations (Public/Private per audience), Mapperly interface, DI registration additions |
| `artifact-planner:efcore` | `IEntityTypeConfiguration<T>` per entity, `OnModelCreating` verification notes, `JsonStringEnumConverter` registration (if missing) |

## Input envelope (all variants)

```
{
  layer: "domain" | "domain-shared" | "application-contracts" | "application" | "efcore",
  feature: {slug, pascal, module_count},
  fs_catalog: <full fs-loader output>,
  claude_md_contract: {
    project_root_namespace: string,
    src_path: string,
    module_project_layout: {...} | null,
    tenancy_model: string | null,
    validation_library: "FluentValidation" | "DataAnnotations" | ...,
    object_mapping_library: "Mapperly" | "AutoMapper" | ...,
    permissions_class_pattern: string,           // default "<Feature>Permissions"
    db_table_prefix: string,                     // default "App"
    sorting_strategy: "explicit-switch" | "dynamic-linq",
    enum_serialization: string,
    api_routing_conventions: {public_prefix, private_prefix} | null,
    localization_resource_name: string           // default "<Feature>Resource"
  },
  solution_state: <solution-inspector output>,
  references: [<paths to reference files for this layer>]
}
```

## Domain planner procedure

1. Identify the aggregate root per module (main agent already resolved it; planner double-checks).
2. For the aggregate root, plan:
   - Private constructor.
   - Static `Create(...)` factory delegating to a nested `Builder`.
   - Domain methods — one per postcondition referenced by a Command.
   - `FullAuditedAggregateRoot<Guid>` base; add `IMultiTenant` only if `claude_md_contract.tenancy_model` is declared AND the Entity page's interface list includes `IMultiTenant`.
3. For each child entity, plan `Entity<Guid>` (or the audited base declared on the page) with an internal constructor.
4. For each Value Object, plan a `ValueObject` subclass with fields and `GetAtomicValues()`.
5. **Domain Service decision.** Mandatory when any of:
   - Multi-aggregate state change referenced by ≥1 Command.
   - Reorder/ranking across a sibling set.
   - Cross-aggregate calculation.
   - External-system validation.
   - A business rule referenced by ≥2 Commands.
   Otherwise omitted. When included, plan public async methods per orchestration operation.
6. Emit a file descriptor per planned artifact.

## Domain.Shared planner procedure

1. For each State node, plan `<StateName>Enum.cs` with explicit `int` values mirroring the page's `int_value` field.
2. Plan `<Feature>Constants.cs` with:
   - Business-value constants (field max-lengths, regex patterns) referenced in the Entity attribute tables.
   - A nested `public static class ErrorMessages` holding localization keys — keys only, never strings.
3. Plan `<Feature>Roles.cs` with one constant per actor with a human actor.
4. Plan `<Feature>Resource.cs` — an empty marker class for `IStringLocalizer<T>`.
5. Plan `Localization/Resources/<Feature>/en.json`:
   - Every `error_messages[i].key` from FS catalog → `error_messages[i].text_en`.
   - Every permission → `<Feature>:Permission:<Name>` → human label from the permission page.
   - Any default validator message key the Application.Contracts planner registers.

## Application.Contracts planner procedure

1. **Permissions pair.** Plan two files:
   - `Permissions/<Feature>Permissions.cs` — `public static class <Feature>Permissions` with:
     - `public const string GroupName = "<Feature>";`
     - Nested `public static class <Entity>` per entity:
       - `public const string Default = GroupName + ":<Entity>";`
       - `Create`, `Read`, `Update`, `Delete` children.
       - Custom operations from FS Permission entries (e.g. `Reorder`, `Approve`).
   - `Permissions/<Feature>PermissionDefinitionProvider.cs` — inherits `PermissionDefinitionProvider`; `Define(IPermissionDefinitionContext)` registers group → parent → children with `L("<Feature>:Permission:<n>")`.
2. **DTOs.** Per entity:
   - `Dtos/Create<Entity>Dto.cs` — init-only, no `Id`, includes every required attribute from the Entity page not auto-populated (no `TenantId`, no audit).
   - `Dtos/Update<Entity>Dto.cs` — init-only, includes `Id`, `ConcurrencyStamp`, plus every mutable attribute.
   - `Dtos/<Entity>Dto.cs` — output DTO with `{ get; set; }`, includes audit fields exposed by the page.
   - `Dtos/Get<Entity>ListDto.cs` — extends `PagedAndSortedResultRequestDto` if paged per the Query page; filter fields per the Query's optional filters.
3. **Validators.** Per input DTO, one `FluentValidation.AbstractValidator<T>`:
   - Rule per FS precondition/constraint.
   - Inject `IStringLocalizer<<Feature>Resource>`.
   - Reference keys from `<Feature>Constants.ErrorMessages`.
4. **AppService interfaces.** Split per `api_routing_conventions`:
   - If both Public and Private prefixes declared → `I<Feature>PublicAppService` + `I<Feature>PrivateAppService`, each routing its Audience-matching Commands and Queries.
   - Else → single `I<Feature>AppService`.
   - Methods use the exact signatures the AppService implementations will implement. Must inherit `IApplicationService`.
5. **Audience-missing halt.** If CLAUDE.md declares a split and any Command/Query has `audience: null`, return `{halt: "PUBLIC_PRIVATE_SPLIT_MISSING_AUDIENCE", offenders: [...]}`.

## Application planner procedure

1. **AppService implementations.** Mirror the interfaces. For each method:
   - Declare `[Authorize(<Feature>Permissions.<Entity>.<Op>)]` — reads AND writes.
   - Plan constructor injection: `IRepository<<AggregateRoot>, Guid>`, `<Feature>Service` (if domain service planned), `I<Feature>Mapper`.
   - Plan tenancy guard: `if (entity.TenantId != CurrentTenant.Id) throw new AbpAuthorizationException(...)` after every load when `IMultiTenant` present.
   - For Queries: plan sorting per `sorting_strategy`. `explicit-switch` generates a `switch` statement over whitelisted column keys defaulting to the page's `default_sort`. `dynamic-linq` uses `System.Linq.Dynamic.Core` — allowed only when the contract explicitly says so.
   - For paged Queries: plan `AsyncExecuter.CountAsync(query)` + `ToListAsync(query.PageBy(input))` + `PagedResultDto<T>`.
2. **Mapperly interface.** Plan `<Feature>Mapper.cs`:
   - `[Mapper]` attribute.
   - Public interface `I<Feature>Mapper`.
   - One `MapToOutput(<Entity>)` per entity.
   - One `MapToOutputList(IEnumerable<<Entity>>)` per entity.
   - No property-by-property bodies; Mapperly generates them.
3. **DI registration.** Plan additions to `<Feature>ApplicationModule.ConfigureServices`:
   - `context.Services.AddScoped<I<Feature>Mapper, <Feature>Mapper>();`
   - `context.Services.AddScoped<<Feature>Service>();` if domain service planned.
   - `context.Services.AddScoped<I<Feature>PublicAppService, <Feature>PublicAppService>();` etc.
   - `context.Services.AddValidatorsFromAssembly(typeof(<Feature>ApplicationModule).Assembly);` (only once per module — dedupe if already present).

## EFCore planner procedure

1. Per entity, plan `<Feature>/<Entity>Configuration.cs`:
   - Inherits `IEntityTypeConfiguration<<Entity>>`.
   - `Configure(EntityTypeBuilder<<Entity>>)` method:
     - `builder.ToTable(<db_table_prefix> + "<Entity-plural>")`.
     - `builder.ConfigureByConvention()` — ABP convention call.
     - `builder.Property(...)` per attribute with explicit max-length / required from the Entity page.
     - Owned-type mapping per Value Object, or Value Converter if persisted as flat column.
     - Indexes per the Entity page's declared indexes.
     - Relationships per the Entity page's relationships with explicit `OnDelete(...)`.
2. Plan `OnModelCreating` verification note — the inspector confirmed `ApplyConfigurationsFromAssembly` is present, so no module-edit is needed.
3. **Json converter plan.** If `solution_state.json_enum_converter_registered == false`, plan an addition to `<Ns>.HttpApi.Host`'s `Program.cs`:
   - `builder.Services.Configure<JsonOptions>(options => options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter(JsonNamingPolicy.CamelCase)));`
   - This is the only allowed edit outside the feature folder.

## File descriptor shape (all planners)

```
{
  path: string,                    // absolute or src-relative
  layer: string,
  kind: string,                    // "aggregate-root" | "child-entity" | "value-object" | "domain-service" | "enum" | "constants" | "roles" | "resource-class" | "localization-json" | "permissions-constants" | "permission-provider" | "input-dto" | "update-dto" | "output-dto" | "list-request-dto" | "validator" | "appservice-interface" | "appservice-impl" | "mapper-interface" | "ef-configuration" | "di-registration-edit" | "json-converter-edit"
  source_fs_elements: [            // at least one — empty means orphan
    {type: "Entity"|"Command"|"Query"|"State"|"Permission"|"Actor"|"Integration"|"ErrorMessage", name: string, source_link: string}
  ],
  summary_one_line: string,        // for preview
  overwrites_existing: bool,
  dependencies: [path, ...],       // files this file compiles against, for cohort ordering sanity
  convention_notes: [string]       // any CLAUDE.md convention the planner applied
}
```

## Output schema (per worker)

```
{
  layer: string,
  halt: null | "PUBLIC_PRIVATE_SPLIT_MISSING_AUDIENCE" | "UNPLANNABLE_ELEMENT",
  halt_details: {...} | null,
  files: [<file descriptor>...],
  module_edits: [                  // edits to existing files (module classes, HttpApi.Host)
    {target_path, edit_kind, one_line_summary}
  ],
  unmapped_fs_elements: [          // FS elements this layer should cover but cannot
    {fs_element_type, name, reason}
  ],
  warnings: [{code, message}]
}
```

## Halt conditions

- Audience declared split but Command/Query audience missing.
- Entity on FS page with no attributes (Domain planner).
- Query page with `paged: true` but no `default_sort`.
- Validator planned against `DataAnnotations` when `validation_library` = `FluentValidation` (contract violation).
- Mapper planned with AutoMapper when `object_mapping_library` = `Mapperly`.
- Any planned path outside `<src_path>` (security).

## What this sub-agent never does

- Never writes files (it is a planner).
- Never runs builds.
- Never synthesizes code bodies — only file descriptors with summaries.
- Never reads wiki pages directly — it operates on the fs-loader catalog.
- Never decides aggregate roots — main agent does that in Phase 5; planner validates the decision.
