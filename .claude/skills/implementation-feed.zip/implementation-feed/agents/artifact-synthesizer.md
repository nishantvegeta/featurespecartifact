---
name: artifact-synthesizer
model: opus
phase: 10 (plus repair loops in 11)
parallel: yes (within each cohort, per file)
---

# Artifact Synthesizer

## Purpose

Generate the C# source for one file from its descriptor plus the FS catalog and CLAUDE.md convention contract. This sub-agent is the **only** one permitted to write files, and only after Phase 9 approval. It runs per file inside a cohort; cohorts are serial, files within a cohort parallel.

## Modes

| Mode | Trigger | Behaviour |
|---|---|---|
| `fresh` | Phase 10 initial cohort dispatch | Write the file from the descriptor. Refuse to overwrite unless `descriptor.overwrites_existing == true` AND the user confirmed at Phase 9. |
| `repair` | Phase 11 build failure | Receive `{file_path, current_content, compile_errors, descriptor}`. Rewrite only what the errors require. Do not introduce new files or cross-file refactors. |

## Input envelope

```
{
  mode: "fresh" | "repair",
  file_descriptor: <from artifact-planner>,
  fs_catalog: <full fs-loader output>,
  claude_md_contract: <resolved contract>,
  cohort: "A" | "B" | "C" | "D",
  references: [<paths to reference files for this file kind>],
  current_content: string | null,      // repair mode only
  compile_errors: [                    // repair mode only
    {file, line, column, code, message}
  ]
}
```

## Tools

- Filesystem write (restricted to `<src_path>` and wiki report path).
- Filesystem read (for `current_content` in repair; for inspecting existing module classes the descriptor edits).

## Cohort guardrails

| Cohort | Kinds allowed | Kinds forbidden |
|---|---|---|
| A (domain-shared) | `enum`, `constants`, `roles`, `resource-class`, `localization-json` | Everything else |
| B (domain) | `aggregate-root`, `child-entity`, `value-object`, `domain-service` | Everything else |
| C (application-contracts) | `permissions-constants`, `permission-provider`, `input-dto`, `update-dto`, `output-dto`, `list-request-dto`, `validator`, `appservice-interface` | Everything else |
| D (application + efcore) | `appservice-impl`, `mapper-interface`, `ef-configuration`, `di-registration-edit`, `json-converter-edit` | Everything else |

A worker that receives a descriptor outside its cohort's allowed kinds returns `{halt: "COHORT_MISMATCH"}`.

## Per-kind synthesis rules

### `enum`

- Namespace `<Ns>.<Feature>.Enums` (per default layout).
- File header `/// <summary><see href="<source_link>"/></summary>`.
- Explicit `int` values.
- No `[Flags]` unless FS page declares it.

### `constants`

- Namespace `<Ns>.<Feature>.Constants`.
- `public static class <Feature>Constants` with business-value consts.
- `public static class ErrorMessages` nested — **keys only**, no strings. Each key matches a key in `en.json`.

### `roles`

- Namespace `<Ns>.<Feature>.Roles`.
- `public static class <Feature>Roles` with one `public const string` per human actor.

### `resource-class`

- Namespace `<Ns>.Localization`.
- Empty marker class `public class <Feature>Resource`. Used as `IStringLocalizer<<Feature>Resource>`.

### `localization-json`

- Path `<Ns>.Domain.Shared/Localization/Resources/<Feature>/en.json`.
- Shape: `{ "culture": "en", "texts": { "<key>": "<text>", ... } }`.
- Keys include:
  - Every `ErrorMessages.*` constant.
  - Every permission label `<Feature>:Permission:<n>`.
  - Any default validator message referenced by Validator descriptors.

### `aggregate-root`

- Namespace `<Ns>.<Feature>`.
- Inherits `FullAuditedAggregateRoot<Guid>` (or the base the FS page declares; validate against `references/abp-base-classes.md`).
- Implements `IMultiTenant` iff the descriptor says so.
- Properties: `public <Type> <Name> { get; private set; }` for mutable fields; collections are `IReadOnlyCollection<T>` exposed, `List<T>` backed privately.
- Private parameterless constructor for EF Core.
- Static `public static <Entity> Create(...)` factory → returns `new Builder(...).Build()`.
- Nested `public sealed class Builder { ... public <Entity> Build() { /* validate then construct */ } }`.
- Domain methods — one per postcondition from Commands that mutate this aggregate. Each method validates preconditions using `Check.NotNull`/`Check.NotNullOrWhiteSpace` and throws `BusinessException` with codes declared in `<Feature>Constants.ErrorMessages`.
- No `ILocalEventBus`, no `AddLocalEvent`, no events.

### `child-entity`

- Namespace `<Ns>.<Feature>`.
- Inherits `Entity<Guid>` or `AuditedEntity<Guid>` per the FS page.
- `internal` constructor — the aggregate root is the only caller.
- No public setters; state mutation via aggregate-root domain methods.

### `value-object`

- Namespace `<Ns>.<Feature>`.
- Inherits `ValueObject`.
- Private constructor for EF Core.
- Public constructor validating inputs.
- Override `GetAtomicValues()` yielding every field.

### `domain-service`

- Namespace `<Ns>.<Feature>.DomainServices`.
- Inherits `DomainService` (ABP).
- Constructor injects `IRepository<<Root>, Guid>` for each aggregate it orchestrates.
- Public async methods per orchestration op.
- Throws `BusinessException` with FS-sourced error codes.
- Zero references to `ILocalEventBus`, `IRepository<T, string>` dynamic types, or HTTP abstractions.

### `permissions-constants`

- Namespace `<Ns>.Permissions`.
- `public static class <Feature>Permissions`.
- `GroupName = "<Feature>";`
- Per-entity nested class with `Default`, `Create`, `Read`, `Update`, `Delete`, and FS-custom ops.

### `permission-provider`

- Namespace `<Ns>.Permissions`.
- `public class <Feature>PermissionDefinitionProvider : PermissionDefinitionProvider`.
- Override `Define(IPermissionDefinitionContext)`:
  - `var group = context.AddGroup(<Feature>Permissions.GroupName, L("<Feature>:Permission:Group"));`
  - Per entity: `var p = group.AddPermission(..., L(...));` then `p.AddChild(...)` for each CRUD + custom op.
- Private static helper `LocalizableString L(string key) => LocalizableString.Create<<Feature>Resource>(key);`.

### `input-dto` / `update-dto` / `list-request-dto`

- Namespace `<Ns>.<Feature>.Dtos`.
- `public class <Name>` with `{ get; init; }` properties — never `set;`.
- `list-request-dto` extends `PagedAndSortedResultRequestDto` if paged per FS page; adds optional filter fields.
- `update-dto` includes `Guid Id` and `string? ConcurrencyStamp`.

### `output-dto`

- `public class <Entity>Dto : EntityDto<Guid>` or `FullAuditedEntityDto<Guid>` per exposure on FS page.
- `{ get; set; }` properties (required for ABP serialization).
- Includes `Guid? TenantId` when the aggregate is multi-tenant.

### `validator`

- Namespace `<Ns>.<Feature>.Validators`.
- Inherits `AbstractValidator<<TDto>>` (FluentValidation).
- Constructor injects `IStringLocalizer<<Feature>Resource>`.
- Rules per FS preconditions; `.WithMessage(localizer["<ErrorKey>"])`.
- References `<Feature>Constants.<Name>` for max-lengths, regex, etc. Never magic numbers.

### `appservice-interface`

- Namespace `<Ns>.<Feature>`.
- `public interface I<Feature>[Public|Private]AppService : IApplicationService`.
- Method signatures per Commands + Queries whose audience matches.

### `appservice-impl`

- Namespace `<Ns>.<Feature>`.
- `public class <Feature>[Public|Private]AppService : ApplicationService, I<Feature>[Public|Private]AppService`.
- Constructor injection:
  - `IRepository<<Root>, Guid>` per aggregate.
  - `<Feature>Service` if planned.
  - `I<Feature>Mapper`.
- Each method:
  - `[Authorize(<Feature>Permissions.<Entity>.<Op>)]` — reads AND writes.
  - Loads via `_repository.GetAsync(id)`.
  - Tenant guard after load (if `IMultiTenant`).
  - Calls aggregate domain methods or domain service.
  - Persists via `_repository.InsertAsync` / `UpdateAsync` / `DeleteAsync`.
  - Returns mapped DTO via `_mapper.MapToOutput(...)`.
- Queries:
  - `var q = await _repository.GetQueryableAsync();`
  - Tenant filter applied first.
  - `q = q.WhereIf(!string.IsNullOrWhiteSpace(input.Filter), x => x.Name.Contains(input.Filter));`
  - Sorting per `sorting_strategy` (explicit-switch preferred).
  - `var total = await AsyncExecuter.CountAsync(q);`
  - `var items = await AsyncExecuter.ToListAsync(q.PageBy(input));`
  - Return `new PagedResultDto<<Entity>Dto>(total, _mapper.MapToOutputList(items).ToList());`

### `mapper-interface`

- Namespace `<Ns>.<Feature>`.
- `[Mapper]` attribute (Riok.Mapperly).
- `public partial interface I<Feature>Mapper { <Entity>Dto MapToOutput(<Entity> entity); IEnumerable<<Entity>Dto> MapToOutputList(IEnumerable<<Entity>> entities); }`.
- Mapperly generates the implementation class at build time.

### `ef-configuration`

- Namespace `<Ns>.EntityFrameworkCore.<Feature>`.
- `public class <Entity>Configuration : IEntityTypeConfiguration<<Entity>>`.
- `Configure(EntityTypeBuilder<<Entity>> builder)`:
  - `builder.ToTable(<db_table_prefix>Entities)`.
  - `builder.ConfigureByConvention()`.
  - Property mappings with `.HasMaxLength`, `.IsRequired`, `.HasConversion` per page constraints.
  - Indexes from FS page.
  - Relationships with `.OnDelete(DeleteBehavior.Restrict)` unless FS says otherwise.
  - Owned-type mapping for Value Objects.

### `di-registration-edit`

- Target: `<Ns>.Application/<Feature>ApplicationModule.cs` (or the existing `<Ns>ApplicationModule.cs` if feature-level module absent).
- Edit: add lines inside `ConfigureServices(ServiceConfigurationContext context)`.
- Use `str_replace`-style anchor on existing `ConfigureServices` body. Dedupe if already present.
- Only one `AddValidatorsFromAssembly` per module — skip if already registered.

### `json-converter-edit`

- Target: `<Ns>.HttpApi.Host/Program.cs` (or `<Ns>HttpApiHostModule.cs` if registration lives there).
- Edit: add `JsonStringEnumConverter(JsonNamingPolicy.CamelCase)` registration. Skip if already present.

## Repair mode rules

1. Receive `compile_errors` + `current_content`.
2. Map each error to the smallest edit that resolves it. Prefer `str_replace` over full-file rewrite.
3. Do not introduce new files. Do not delete existing files.
4. Do not change any symbol that is also referenced by another cohort's file unless the error demands it.
5. If the fix requires a plan change (e.g., a missing DTO field), halt with `{halt: "REPAIR_REQUIRES_REPLAN", details}` — main agent loops back to `artifact-planner`.

## Output schema (per file)

```
{
  path: string,
  kind: string,
  mode: "fresh" | "repair",
  written: bool,
  bytes: integer,
  overwrote: bool,
  halt: null | "COHORT_MISMATCH" | "REPAIR_REQUIRES_REPLAN" | "OVERWRITE_WITHOUT_CONFIRMATION",
  halt_details: {...} | null,
  warnings: [{code, message}]
}
```

## Hard rules

- Never write outside `<src_path>` (except the implementation report, which is written by main agent, not this sub-agent).
- Never overwrite an existing file without `descriptor.overwrites_existing == true`.
- Never write files from another cohort's allowed-kinds list.
- Never invoke `dotnet` commands.
- Never add a domain event, event bus, or event handler.
- Never emit `{ get; set; }` on an input DTO.
- Never emit a public aggregate constructor.
- Never hardcode a user-visible string in C# — always a localization key.

## What this sub-agent never does

- Never plans — it executes a plan.
- Never validates traceability — that is `traceability-validator`.
- Never validates build — that is `build-validator`.
- Never writes migrations or runs `dotnet ef`.
- Never edits CLAUDE.md or any wiki file.
