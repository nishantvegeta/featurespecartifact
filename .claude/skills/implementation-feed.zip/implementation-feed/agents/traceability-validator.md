---
name: traceability-validator
model: haiku
phase: 7
parallel: no
---

# Traceability Validator

## Purpose

Verify the merged artifact manifest (output of `artifact-planner` × 5) satisfies three properties:

1. **Forward coverage** — every FS element has at least one artifact.
2. **Backward provenance** — every artifact has at least one FS source.
3. **Convention compliance** — no artifact contradicts CLAUDE.md.

This is the last gate before the user sees the preview. Failure halts the skill and surfaces a structured gap report.

## Input envelope

```
{
  fs_catalog: <full fs-loader output>,
  merged_manifest: {
    domain:                [<file descriptor>...],
    domain_shared:         [<file descriptor>...],
    application_contracts: [<file descriptor>...],
    application:           [<file descriptor>...],
    efcore:                [<file descriptor>...],
    module_edits:          [<module-edit>...]
  },
  claude_md_contract: <resolved contract>
}
```

## Tools

- None. Pure computation over the envelope.

## Procedure

### 1. Forward coverage checks

Each FS element type has an expected artifact projection. For each element, enumerate required artifact kinds and confirm each exists in the manifest:

| FS element | Required artifact kinds | Located in |
|---|---|---|
| Actor (human) | `roles` constant entry | domain-shared |
| Actor (system) | (no artifact required; recorded for docs) | — |
| Entity (aggregate root) | `aggregate-root` + `ef-configuration` + `output-dto` | domain, efcore, application-contracts |
| Entity (child) | `child-entity` + `ef-configuration` | domain, efcore |
| Value Object | `value-object` + `ef-configuration` (owned-type or value-converter) | domain, efcore |
| Command | `input-dto` + `validator` + `appservice-interface` method + `appservice-impl` method | application-contracts × 3 + application |
| Query | `list-request-dto` OR filter DTO + `appservice-interface` method + `appservice-impl` method | application-contracts × 2 + application |
| State | `enum` + registration in `JsonStringEnumConverter` (global) | domain-shared + module edit (if missing) |
| Permission | constant in `permissions-constants` + registration in `permission-provider` | application-contracts × 2 |
| Integration | port interface declaration (descriptor only) | application-contracts or domain |
| Error message | key in `<Feature>Constants.ErrorMessages` + text in `<lang>.json` | domain-shared × 2 |
| Business rule (aggregate-scoped) | domain method on the relevant entity | domain |
| Business rule (multi-aggregate) | method on `<Feature>Service` domain service | domain |

**Gap** — any required artifact kind missing → defect `FORWARD_GAP`.

### 2. Backward provenance checks

For every file descriptor in the merged manifest, verify `source_fs_elements` has length ≥ 1. For each referenced FS element, verify it exists in `fs_catalog`.

**Defect** `BACKWARD_ORPHAN` when:
- `source_fs_elements` is empty.
- A referenced `{type, name}` does not exist in the catalog.

Exceptions — these file kinds are allowed to source from a synthetic "framework" element recorded in the catalog (they have no FS page but are mechanically required):
- `resource-class` — sourced from the feature as a whole.
- `mapper-interface` — sourced from the set of entities it maps.
- `di-registration-edit` — sourced from the AppService implementations it registers.
- `json-converter-edit` — sourced from the set of State enums.

### 3. Convention compliance checks

Walk every file descriptor and check:

| Check | Violation code |
|---|---|
| Validator descriptor uses CLAUDE.md `validation_library` base class | `CONVENTION_VALIDATION_LIBRARY` |
| Mapper descriptor uses CLAUDE.md `object_mapping_library` attribute/pattern | `CONVENTION_MAPPING_LIBRARY` |
| Query list descriptor sort pattern matches CLAUDE.md `sorting_strategy` | `CONVENTION_SORTING` |
| Aggregate descriptor includes `IMultiTenant` iff CLAUDE.md `tenancy_model` AND Entity page interface list | `CONVENTION_TENANCY` |
| Table name uses `db_table_prefix` + PascalCase plural | `CONVENTION_TABLE_PREFIX` |
| Permission constants class name matches `permissions_class` pattern | `CONVENTION_PERMISSIONS_CLASS` |
| Localization resource class name matches `localization_resource_name` | `CONVENTION_RESOURCE_NAME` |
| All namespaces prefix with `project_root_namespace` | `CONVENTION_NAMESPACE` |
| No file planned outside `src_path` | `SECURITY_PATH_ESCAPE` |

### 4. Hard-rule checks

Cross-check invariants from the skill's `<HARD-GATE>`:

| Check | Violation code |
|---|---|
| Every AppService impl method descriptor includes `[Authorize(...)]` | `HARD_AUTHZ_MISSING` |
| `<Feature>Permissions` exists iff `<Feature>PermissionDefinitionProvider` exists | `HARD_PERMISSIONS_PAIR` |
| Every input/update DTO descriptor is init-only | `HARD_DTO_MUTABILITY` |
| No descriptor in the Domain layer references `ILocalEventBus` / `IDistributedEventBus` | `HARD_DOMAIN_EVENTS` |
| Aggregate-root descriptor uses Builder pattern | `HARD_BUILDER` |
| `dotnet ef migrations` / `database update` never appears in any planned script or file | `HARD_MIGRATION_IN_SCOPE` |
| `IHasExtraProperties` absent from all entity descriptors | `HARD_EXTRA_PROPERTIES` |

### 5. Cohort dependency check

For each file descriptor's `dependencies`, confirm the referenced files exist in the manifest and belong to an earlier or the same cohort:

| File's cohort | May depend on |
|---|---|
| A (domain-shared) | — |
| B (domain) | A |
| C (application-contracts) | A |
| D (application + efcore) | A, B, C |

Back-edge (later cohort depended on by earlier) → `COHORT_INVERSION`.

## Output schema

```
{
  passed: bool,
  defect_count_by_severity: {critical: int, high: int, medium: int},
  defects: [
    {
      code: string,                   // one of the codes above
      severity: "critical"|"high"|"medium",
      message: string,
      where: string | null,           // file descriptor path or "FS:<name>"
      fs_source: string | null,       // wiki link when relevant
      suggested_fix: string           // actionable, one line
    }
  ],
  coverage_matrix: {                  // for the preview
    fs_element_key: [artifact_path, ...]
  },
  convention_summary: {
    validation_library: "compliant" | "violating",
    object_mapping_library: "compliant" | "violating",
    sorting_strategy: "compliant" | "violating",
    tenancy_model: "compliant" | "violating" | "not_declared",
    ...
  }
}
```

## Halt behaviour

`passed: false` halts the skill. Main agent surfaces the defect list and either:

- Loops back to `artifact-planner` in repair mode with the defect list as input (if defects are planner-fixable), OR
- Loops back to `fs-loader` + main-agent Phase 4 (if the gap is in the FS itself — e.g., a Command references an Entity the FS catalog doesn't have).

Cap: 2 repair loops. After that, halt and require user intervention.

## What this sub-agent never does

- Never reads files from disk (operates on the envelope only).
- Never edits the manifest (read-only validator).
- Never calls `AskUserQuestion`.
- Never decides how to fix a defect — it only reports and suggests.
