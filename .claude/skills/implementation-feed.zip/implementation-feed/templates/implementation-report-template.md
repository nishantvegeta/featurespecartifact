# Implementation Report Template

This template is written by the main agent at Phase 12 to `<wiki_local_path>/feat-specs/<feature-slug>/IMPLEMENTATION_REPORT_<Feature>.md`. It is a mirror of what happened, not a re-derivation of the plan.

## Layout

```
# Implementation Report — <Feature Title>

**Feature slug:** <feature-slug>
**Generated:** <ISO-8601 timestamp>
**Feat Spec:** [<Feature Title>](<wiki_url>/feat-specs/<feature-slug>/feat-spec)
**Skill version:** implementation-feed <vX.Y.Z>

---

## 1. Summary

<One paragraph. Module count, aggregate count, total file count, build status.>

---

## 2. CLAUDE.md Convention Contract Resolved

| Field | Value | Source |
|---|---|---|
| project_root_namespace | <Ns> | CLAUDE.md |
| src_path | <src> | CLAUDE.md |
| tenancy_model | <value or "not declared"> | CLAUDE.md / default |
| validation_library | <value> | CLAUDE.md / default |
| object_mapping_library | <value> | CLAUDE.md / default |
| sorting_strategy | <value> | CLAUDE.md / default |
| permissions_class | <value> | CLAUDE.md / default |
| db_table_prefix | <value> | CLAUDE.md / default |
| enum_serialization | <value> | CLAUDE.md / default |
| api_routing_conventions | <single | public+private> | CLAUDE.md / default |

**Defaults used (CLAUDE.md did not declare):** <list, or "none">.

---

## 3. File Inventory

### Domain layer (<n> files)

| Path | Kind | FS source |
|---|---|---|
| src/<Ns>.Domain/<F>/<Root>.cs | aggregate-root | [<Root>](<wiki>/entities/<Root>) |
| src/<Ns>.Domain/<F>/DomainServices/<F>Service.cs | domain-service | [<F> flows](<wiki>/flows/<F>) |
| ... | ... | ... |

### Domain.Shared layer (<n> files)

| Path | Kind | FS source |
|---|---|---|
| src/<Ns>.Domain.Shared/<F>/Enums/<State>Enum.cs | enum | [<State>](<wiki>/states/<State>) |
| src/<Ns>.Domain.Shared/<F>/Constants/<F>Constants.cs | constants | <feature-level> |
| src/<Ns>.Domain.Shared/<F>/Roles/<F>Roles.cs | roles | [Actors](<wiki>/feat-specs/<slug>/feat-spec#actors) |
| src/<Ns>.Domain.Shared/<F>/Localization/<F>Resource.cs | resource-class | <feature-level> |
| src/<Ns>.Domain.Shared/Localization/Resources/<F>/en.json | localization-json | <feature-level> |

### Application.Contracts layer (<n> files)

| Path | Kind | FS source |
|---|---|---|
| src/<Ns>.Application.Contracts/<F>/Permissions/<F>Permissions.cs | permissions-constants | [Permissions map](<wiki>/feat-specs/<slug>/feat-spec#permissions-security-and-multi-tenancy) |
| src/<Ns>.Application.Contracts/<F>/Permissions/<F>PermissionDefinitionProvider.cs | permission-provider | (same) |
| src/<Ns>.Application.Contracts/<F>/Dtos/Create<E>Dto.cs | input-dto | [Create<E>](<wiki>/commands/Create<E>) |
| ... | ... | ... |

### Application layer (<n> files)

| Path | Kind | FS source |
|---|---|---|
| src/<Ns>.Application/<F>/<F>PublicAppService.cs | appservice-impl | (multiple commands/queries with Audience=Public) |
| src/<Ns>.Application/<F>/<F>PrivateAppService.cs | appservice-impl | (multiple commands/queries with Audience=Private) |
| src/<Ns>.Application/<F>/<F>Mapper.cs | mapper-interface | (entities) |

### EntityFrameworkCore layer (<n> files)

| Path | Kind | FS source |
|---|---|---|
| src/<Ns>.EntityFrameworkCore/<F>/<E>Configuration.cs | ef-configuration | [<E>](<wiki>/entities/<E>) |
| ... | ... | ... |

### Module edits (<n> files)

| Path | Edit | Summary |
|---|---|---|
| src/<Ns>.Application/<Ns>ApplicationModule.cs | di-registration-edit | Registered I<F>Mapper, <F>Service, AppServices, FluentValidation assembly |
| src/<Ns>.HttpApi.Host/Program.cs | json-converter-edit | Added JsonStringEnumConverter(CamelCase) |

---

## 4. Traceability Matrix

### Forward — FS element → artifacts

| FS element | Type | Artifacts |
|---|---|---|
| Actor: `Customer` | Actor | <Ns>.Domain.Shared/<F>/Roles/<F>Roles.cs#Customer |
| Entity: `LoanApplication` | Entity | <Ns>.Domain/<F>/LoanApplication.cs, <Ns>.EntityFrameworkCore/<F>/LoanApplicationConfiguration.cs, <Ns>.Application.Contracts/<F>/Dtos/LoanApplicationDto.cs |
| Command: `SubmitApplication` | Command | Dtos/SubmitApplicationDto.cs, Validators/SubmitApplicationValidator.cs, I<F>PublicAppService.SubmitAsync(), <F>PublicAppService.SubmitAsync() |
| Query: `GetApplicationList` | Query | Dtos/GetLoanApplicationListDto.cs, I<F>PrivateAppService.GetListAsync(), <F>PrivateAppService.GetListAsync() |
| State: `LoanStatus` | State | Enums/LoanStatusEnum.cs + Program.cs registration |
| Permission: `Application:Approve` by `Underwriter` | Permission | <F>Permissions.Application.Approve + <F>PermissionDefinitionProvider |
| Error: `ApplicantNameRequired` | ErrorMessage | Constants/<F>Constants.ErrorMessages.ApplicantNameRequired + en.json entry |
| Integration: `CreditBureauApi` | Integration | (port interface descriptor — not implemented by this skill) |

### Backward — artifact → FS source (via file XML doc `<see href="..."/>`)

Every artifact file carries its `<see href="...">` — verified by `traceability-validator`. Zero orphans.

---

## 5. Convention Compliance Summary

| Check | Result |
|---|---|
| All validators use FluentValidation | ✅ |
| All mappers use Mapperly | ✅ |
| All sorts use explicit-switch | ✅ |
| Tenancy guards present where IMultiTenant | ✅ |
| Permissions pair (constants + provider) | ✅ |
| [Authorize] on every AppService method | ✅ |
| No domain events in Domain layer | ✅ |
| All input DTOs init-only | ✅ |
| No hardcoded user-visible strings | ✅ |
| All namespaces under <Ns> | ✅ |

---

## 6. Build Status

```
dotnet build <solution> --nologo --no-restore -v quiet
Exit code: 0
Errors:   0
Warnings: <n>
```

Iterations to green: <0|1|2|3>.

<If warnings, list the top 5 with file + message.>

---

## 7. Seed-data suggestion (Permissions grants)

This skill generates permission **definitions**. Granting them to roles is a seed/deployment concern. The intended grants from the Feat Spec's Permissions Map:

| Role | Permissions |
|---|---|
| `Customer` | `<F>:Application:Create`, `<F>:Application:Read` |
| `Underwriter` | `<F>:Application:*` |
| `Administrator` | `<F>:*` |

Add these to `<Ns>.Domain/Data/<Ns>DataSeedContributor` (or wherever the project seeds permissions).

---

## 8. Manual Next Steps

**1. Create the EF migration:**

```
dotnet ef migrations add Add<Feature>Tables \
  --context <Ns>DbContext \
  --output-dir Migrations \
  --project src/<Ns>.EntityFrameworkCore \
  --startup-project src/<Ns>.HttpApi.Host
```

**2. Apply the migration:**

```
dotnet ef database update \
  --context <Ns>DbContext \
  --project src/<Ns>.EntityFrameworkCore \
  --startup-project src/<Ns>.HttpApi.Host
```

**3. Seed permission grants** — see section 7.

**4. Author tests:**

- Domain layer: one test class per aggregate with Builder invariant tests, domain-method happy paths, domain-method precondition failures.
- Application layer: one test class per AppService with authorization tests, tenant isolation tests, happy-path CRUD, validator hits.
- EF Core: one integration test per entity exercising save/load round-trip and unique-index behavior.

**5. Code review checklist:**

- Every file's `<see href="...">` points to the wiki page that exists.
- No hardcoded strings.
- No `System.Linq.Dynamic.Core` (unless CLAUDE.md opts in).
- No `[AllowAnonymous]` on any AppService method.
- Every `Update*Dto` carries `ConcurrencyStamp`.
- Every `IMultiTenant` aggregate has a tenant guard in every AppService method that loads it.

**6. Commit & push:**

```
git add src/<Ns>.Domain src/<Ns>.Domain.Shared src/<Ns>.Application.Contracts src/<Ns>.Application src/<Ns>.EntityFrameworkCore
git add docs/feat-specs/<feature-slug>/IMPLEMENTATION_REPORT_<Feature>.md
git commit -m "feat(<feature-slug>): implement <Feature Title>"
```

---

## 9. Known Deviations

<Any convention-variance notes. If none: "None.">

---

## 10. Open Conflicts (non-blocking)

<Conflicts from the Feat Spec that did not halt the skill because they were medium/low severity. Copied verbatim with wiki links. If none: "None.">

---

*This report was generated by the `implementation-feed` skill. The code it describes is the authoritative artifact; this file mirrors that code for review.*
```

## Notes for main agent

- Generate the report **after** `build-validator` returns `passed: true`. If the skill halted earlier, no report is written — instead the main agent surfaces a halt summary directly to the user.
- Fill every placeholder (`<Ns>`, `<F>`, `<Feature>`, etc.) with concrete values from the resolved CLAUDE.md contract and the artifact manifest.
- Never include code bodies in the report — only file paths and one-line summaries. The code is the source of truth; the report is a map.
- Keep the manual-next-steps section exact — the user will copy-paste those commands.
